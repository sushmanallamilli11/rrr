package runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(format = { "pretty", "html:Reports",
		"json:/Reports/cucumber-report.json" },
		features = {"src/test/resource" },
		glue = "stepDefinitions",
		tags = { "@nocovid" })

public class Runner {

}
