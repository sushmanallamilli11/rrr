package Screens;

import Utilities.CommonOperations;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import stepDefinitions.Hooks;

public class ReturnSafeLogin extends CommonOperations {
    AndroidDriver<MobileElement> driver;
    CommonOperations cop;

    public ReturnSafeLogin(){
        driver = Hooks.driver;
    }

    private final By Return_Login = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Find My ReturnSafe Space"));
    private final By Workspace_Code = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Workspace code"));
    private final By Continue = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Continue"));
    private final By Sign_In = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Sign in"));
    private final By FullName = By.xpath(String.format
            (XPathSelectorPatten.patternText, "First and Last Name"));
    private final By EmailId = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Email Address"));
    private final By Phnumber = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Phone Number"));
    private final By SeeHow = By.xpath(String.format
            (XPathSelectorPatten.patternText, "See How"));
    private final By Next = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Next"));
    private final By Verify = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Verify"));
    private final By CheckIn = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Check In"));
    private final By NoCovid = By.xpath(String.format
            (XPathSelectorPatten.patternText, "No, I have not been tested for COVID-19"));
    private final By Cough = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Cough"));
    private final By Household = By.xpath(String.format
            (XPathSelectorPatten.patternText, "No, No one in my household has been tested for COVID-19"));
    private final By CheckClear = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Your Check-in was Clear"));
    private final By WFH = By.xpath(String.format
            (XPathSelectorPatten.patternText, "Work from Home"));


    public void loginReturnSafe() {

        try {
            waitUntilElementPresence(Return_Login, 10);
            Click(Return_Login);
        } catch (Exception e) {

        }

    }

    public void workSpaceCode() {
        try {
            waitUntilElementPresence(Workspace_Code, 10);
            sendKeys(Workspace_Code, "ReturnSafe");
            Click(Continue);
            Click(Sign_In);

        } catch (Exception e) {

        }

    }

    public void registerEmployee() {
        try {
            waitUntilElementPresence(FullName, 10);

            sendKeys(FullName, "Pottam Sushma");
            sendKeys(EmailId, "pottamsushma@gmail.com");
            sendKeys(Phnumber, "3104080091");
            Click(Sign_In);
            Thread.sleep(40000);
        } catch (Exception e) {

        }

    }


    public void enterVerificationCode() {
        try {
            waitUntilElementPresence(Verify, 10);
            Click(Verify);
            Click(SeeHow);
            Click(Next);
            Click(CheckIn);
        } catch (Exception e) {

        }

    }
    public void noCovidTest() {
        try {
            waitUntilElementPresence(NoCovid, 10);

            Click(NoCovid);
            Click(Next);
            /*Thread.sleep(10000);
            swipe();
            Thread.sleep(10000);*/
            //scroll(234,241,234,1239);
            Click(Cough);
            Click(Next);
            Click(Household);
            Click(Next);
            //Click(CheckClear);

        } catch (Exception e) {

        }

    }

    public void setCheckClear() {
        try {
            waitUntilElementPresence(WFH, 10);
            Click(WFH);

        } catch (Exception e) {

        }

    }
}


