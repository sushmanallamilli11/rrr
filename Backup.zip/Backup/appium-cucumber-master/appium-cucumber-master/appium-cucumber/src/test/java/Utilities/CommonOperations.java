package Utilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import stepDefinitions.Hooks;

import java.time.Duration;
import java.util.HashMap;

import static io.appium.java_client.touch.WaitOptions.waitOptions;

public class CommonOperations {
    //public static AppiumDriver driver;
    public static AndroidDriver<MobileElement> driver;
    private long globalTimeOutInSeconds=120;

    public CommonOperations(){
        this.driver= Hooks.driver;
    }
    
    public WebElement waitUntilElementPresence(final By locator, long timeoutInSeconds) {

        WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator)) ;
         

    }
     public long getGlobalTimeOutSeconds(){
        return globalTimeOutInSeconds;
     }
     
    public void Click(By locator) {
        try {
            waitUntilElementPresence(locator, getGlobalTimeOutSeconds()).click();
        } catch (Exception e) {


        }

    }
    public void sendKeys(By locator,String inputText){
            MobileElement ele = (MobileElement) waitUntilElementPresence(locator, getGlobalTimeOutSeconds());
            ele.setValue(inputText);
            
        }

    public void scroll(int startx, int starty, int endx, int endy) {

        TouchAction touchAction = new TouchAction(driver);

        touchAction.longPress(PointOption.point(startx, starty))
                .moveTo(PointOption.point(endx, endy))
                .release()
                .perform();

    }
    public static void swipe()
    {
        //TouchAction().press(el0).moveTo(el1).release();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, String> swipeObject = new HashMap<String, String>();
        swipeObject.put("direction", "down");
        //swipeObject.put("startX", 164.00);
        //swipeObject.put("startY", y);
       // swipeObject.put("endX", 500.00);
        //swipeObject.put("endY", y);
        //swipeObject.put("duration", 1.0);
        js.executeScript("mobile: swipe", swipeObject);
    }

    public static void horizontalswipe()
    {
        /*JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, Double> swipeObject = new HashMap<String, Double>();
        swipeObject.put("startX", 116.00);
        swipeObject.put("startY", 1268.00);
        swipeObject.put("endX", 164.00);
        swipeObject.put("endY", 1118.00);
        swipeObject.put("duration", 2.0);
        js.executeScript("mobile: swipe", swipeObject);*/
    }
    
    public double generateX(Point point)
    {
        int x=point.getX();
        return x;

    }
    public static double generateY(Point point)
    {
        int y=point.getY();
        return y;

    }


}

