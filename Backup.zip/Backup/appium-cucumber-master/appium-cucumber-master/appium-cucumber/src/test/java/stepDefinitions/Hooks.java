package stepDefinitions;

import Utilities.AppiumServer;
import Utilities.CommonOperations;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Hooks {

    AppiumServer appiumServer = new AppiumServer();
    CommonOperations commop = new CommonOperations();
    /* AppiumDriver<MobileElement> driver; */
    public static AndroidDriver<MobileElement> driver;
    @Before("@setup")
    public void setUp() throws Throwable {

        int port = 4767;
        try {
            if (!appiumServer.checkIfServerIsRunnning(port)) {
                appiumServer.startServer();
                //appiumServer.stopServer();
            } else {
                System.out.println("Appium Server already running on Port - " + port);
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

        driver = appiumServer.startServer();
    }

    @After("@destroy")
    public void tearDown() throws Throwable {
        driver.close();
        appiumServer.stopServer();
    }

}
