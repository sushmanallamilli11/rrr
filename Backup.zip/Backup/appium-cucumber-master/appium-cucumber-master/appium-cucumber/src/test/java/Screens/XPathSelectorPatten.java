package Screens;

import Utilities.CommonOperations;

public class XPathSelectorPatten extends CommonOperations {
     public static final String patternText="//*[@text=\"%1$s\"]";
}
