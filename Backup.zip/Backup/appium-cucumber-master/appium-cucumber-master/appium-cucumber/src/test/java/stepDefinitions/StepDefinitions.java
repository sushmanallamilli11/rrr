package stepDefinitions;

import Screens.ReturnSafeLogin;
import Utilities.CommonOperations;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import Utilities.AppiumServer;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
/*import io.appium.java_client.AppiumDriver;*/
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.MobileElement;

public class StepDefinitions {

	public ReturnSafeLogin rtnSafe;

	public StepDefinitions(ReturnSafeLogin rtnSafe) {
		this.rtnSafe = rtnSafe;
	}

	@Given("^I login to the application$")
	public void i_login_to_the_application() throws Throwable {
		rtnSafe.loginReturnSafe();
		rtnSafe.workSpaceCode();
		rtnSafe.registerEmployee();
		rtnSafe.enterVerificationCode();
	}


	@When("^I select covid tested options as no$")
	public void i_select_covid_tested_options_as_no() throws Throwable {
		rtnSafe.noCovidTest();
	}

	@Then("^I select household covid tested option as no$")
	public void i_select_household_covid_tested_option_as_no() throws Throwable {
		rtnSafe.setCheckClear();
	}
}