$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login.feature");
formatter.feature({
  "line": 2,
  "name": "No Covid Symptoms self and household",
  "description": "",
  "id": "no-covid-symptoms-self-and-household",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@nocovid"
    }
  ]
});
formatter.before({
  "duration": 25291774800,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "Launch Application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 7,
  "name": "No Covid Symptoms self and household",
  "description": "",
  "id": "no-covid-symptoms-self-and-household;no-covid-symptoms-self-and-household",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@setup"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I login to the application",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I select covid tested options as no",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I select household covid tested option as no",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitions.i_login_to_the_application()"
});
formatter.result({
  "duration": 7762173700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.i_select_covid_tested_options_as_no()"
});
formatter.result({
  "duration": 248000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.i_select_household_covid_tested_option_as_no()"
});
formatter.result({
  "duration": 135100,
  "status": "passed"
});
});